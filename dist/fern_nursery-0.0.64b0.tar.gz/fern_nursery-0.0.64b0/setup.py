# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['fern',
 'fern.nursery',
 'fern.nursery.core',
 'fern.nursery.resources',
 'fern.nursery.resources.owner',
 'fern.nursery.resources.owner.errors',
 'fern.nursery.resources.owner.types',
 'fern.nursery.resources.token',
 'fern.nursery.resources.token.errors',
 'fern.nursery.resources.token.types']

package_data = \
{'': ['*']}

install_requires = \
['backports-cached_property==1.0.2',
 'httpx==0.23.3',
 'pydantic>=1.9.2,<2.0.0',
 'types-backports==0.1.3']

setup_kwargs = {
    'name': 'fern-nursery',
    'version': '0.0.64b0',
    'description': '',
    'long_description': 'None',
    'author': 'None',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
